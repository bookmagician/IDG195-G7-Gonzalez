package mx.cetys.arambula.angel.micampus.model

import java.net.URL

enum class EndPoints(val url: URL) {
    PERFIL(URL("http://138.68.231.116:5000/perfil")),
    PLANDEESTUDIOS(URL("http://138.68.231.116:5000/plan"))
}